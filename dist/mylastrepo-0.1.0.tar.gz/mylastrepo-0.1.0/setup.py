from setuptools import setup, find_packages

setup(
    name="mylastrepo",                           
    version="0.1.0",                                
    packages=find_packages(),                       
    description="Un paquete pip simple de saludo",  
    author="Einer Ospino",                         
    author_email="einerpro58@gmail.com",                 
    url="https://github.com/Quesito07/mylastrepo",     
)